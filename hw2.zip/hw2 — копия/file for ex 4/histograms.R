getwd()
x11<-read.csv("table_fslr.csv",header=F)
colnames(x11) <- c("dat","z","opn","mx","mn","clo","vol")
lr11 <-log(x11$clo[-length(x11$clo)]/x11$clo[-1])
or11 <-log(x11$opn/x11$clo)
mr11 <- log(x11$mx/x11$mn)
hist(lr11)


x4<-read.csv("table_fitb.csv",header=F) 
colnames(x4) <- c("dat","z","opn","mx","mn","clo","vol")
or4 <-log(x4$opn/x4$clo)
hist(or4)

x19<-read.csv("table_gis.csv",header=F)
colnames(x19) <- c("dat","z","opn","mx","mn","clo","vol")
lr19 <-log(x19$clo[-length(x19$clo)]/x19$clo[-1])
or19 <-log(x19$opn/x19$clo)
mr19 <- log(x19$mx/x19$mn)
hist(mr19)

