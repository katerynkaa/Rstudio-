getwd()
x1 <- read.csv("table_fhn.csv",header=F) 
colnames(x1) <- c("dat","z","opn","mx","mn","clo","vol")
mr1 <- log(x1$mx/x1$mn)

x2<-read.csv("table_fis.csv",header=F)
colnames(x2) <- c("dat","z","opn","mx","mn","clo","vol")
mr2 <- log(x2$mx/x2$mn)

x20<-read.csv("table_glw.csv",header=F)
colnames(x20) <- c("dat","z","opn","mx","mn","clo","vol")
mr20 <- log(x20$mx/x20$mn)

brks<-seq(min(mr1,mr2, mr20)-0.01,max(mr1,mr2, mr20)+0.01,length.out=30)
hist(mr1,breaks=brks,probability=T,
     main = paste("Historgam based on mr for fhn, mr for fis, mr for glw"), 
     col=rgb(0,0,1,1/4),ylim=c(0,30))
hist(mr2,breaks=brks,probability=T,
     col=rgb(1,0,0,1/4), add=T)
hist(mr20,breaks=brks,probability=T,
     col=rgb(1/4,1,0,1/4), add=T)
legend(x=0.2,y=30,c("mr for fhn","mr for fis", "mr for glw"),
       fill=c(rgb(0,0,1,1/4),rgb(1,0,0,1/4),
              rgb(1/4,1,0,1/4)))
