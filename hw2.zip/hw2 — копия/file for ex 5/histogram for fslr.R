getwd()
x<-read.csv("table_fslr.csv",header=F)
colnames(x) <- c("dat","z","opn","mx","mn","clo","vol")
lr<-log(x$clo[-nrow(x)]/x$clo[-1])
mr<-log(x$mx/x$mn)
or<-log(x$opn/x$clo)

brks<-seq(min(lr,mr, or)-0.01,max(lr,mr, or)+0.01,length.out=50)
hist(lr,breaks=brks,probability=T,
     main = paste("Historgam based on lr, mr, or in fslr"), 
     col=rgb(0,0,1,1/4),ylim=c(0,30))
hist(mr,breaks=brks,probability=T,
     col=rgb(1,0,0,1/4), add=T)
hist(or,breaks=brks,probability=T,
     col=rgb(1/4,0,1/4,1/4), add=T)
legend(x=0.2,y=30,c("lr","mr", "or"),
       fill=c(rgb(0,0,1,1/4),rgb(1,0,0,1/4),
              rgb(1/4,0,1/4,1/4)))
