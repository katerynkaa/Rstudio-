setwd("C:\\Users\\oboga\\Documents\\hw2\\files for ex 1")
x<-read.csv("table_gci.csv",header=F) 
colnames(x) <- c("dat","z","opn","mx","mn","clo","vol")
edit(x)
or1<-log(x$opn/x$clo)
mr <- log(x$mx/x$mn)
lr <-log(x$clo[-length(x$clo)]/x$clo[-1])

