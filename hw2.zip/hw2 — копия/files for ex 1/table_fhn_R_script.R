setwd("C:\\Users\\oboga\\Documents\\hw2\\files for ex 1")
x<-read.csv("table_fhn.csv",header=F) 
colnames(x) <- c("dat","z","opn","mx","mn","clo","vol")
edit(x)
lr <-log(x$clo[-length(x$clo)]/x$clo[-1])
mr <- log(x$mx/x$mn)
or<-log(x$opn/x$clo)

