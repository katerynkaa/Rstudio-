getwd()
x<-read.csv("table_ftr.csv",header=F)
colnames(x) <- c("dat","z","opn","mx","mn","clo","vol")
#edit(x)
lr <-log(x$clo[-length(x$clo)]/x$clo[-1])
mr <- log(x$mx/x$mn)
or<-log(x$opn/x$clo)

medlr<- median(lr)
medor<- median(or)
medmr<- median(mr)

fqlr <- -0.009938708
tqlt <- 0.009828089

quantile(mr)
fqmr <- 0.015397129
tqmr <- 0.033473738

quantile(or)
fqor <- -0.008617369
tqor <- 0.009927635

IQRmr <- IQR(mr)*3/2
IQRlr <- IQR(lr)*3/2
IQRor <- IQR(or)*3/2
